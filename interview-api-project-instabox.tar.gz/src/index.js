const config = require("config");
const createApp = require("./app");

const main = async () => {
  const { app } = await createApp();
  app.listen(config.get("app.port"), () => {
    console.log("Application is running at http://localhost:4000");
  });
};

main().catch(error => {
  console.error(error);
  process.exit(1);
});
